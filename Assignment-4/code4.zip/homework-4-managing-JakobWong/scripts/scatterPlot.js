// this is where your implementation for your scatter plot should go 
function ScatterPlot(svg, data, updateFlowDiagram) {

    var margins = {
        top: 30,
        bottom: 30,
        left: 30,
        right: 30
    };

    this.svg = svg;    
    // grab the bounding box of the container
    var boundingBox = svg.node().getBoundingClientRect();

    //  grab the width and height of our containing SVG
    var svgHeight = boundingBox.height;
    var svgWidth = boundingBox.width;

    // this is where your code should go to generate the flow diagram from the random data

    var height = svgHeight-margins.top-margins.bottom;
    var width = svgWidth-margins.left-margins.right;

    var x = d3.scaleLinear().range([margins.left, width+margins.left]);
    x.domain(d3.extent(data, function(d) {return +d.v0;}));
    var xAxis = d3.axisBottom(x).ticks(10);

    var y = d3.scaleLinear().range([height+margins.bottom,margins.top]);
    y.domain(d3.extent(data, function(d) {return +d.v1;}));
    var yAxis = d3.axisLeft(y).ticks(10);

    this.svg.append("svg")
            .attr("width", svgWidth)
            .attr("height", svgHeight)
          .append("g")
            .attr("transform", `translate(${margins.left}, ${margins.top})`);

    this.svg.append('g')
        .attr("class","xaxis")
        .attr('transform', `translate(${0}, ${height+margins.top})`)
        .style('font-style', 'italic')
        .call(xAxis);

    this.svg.append('g')
        .attr("class","yaxis")
        .attr('transform', `translate(${margins.left}, ${0})`)
        .style('font-style', 'italic')
        .call(yAxis);

    var circle = this.svg.selectAll("circle").data(data);

    // var t = d3.transition().duration(1750);

    circle.enter().append("circle")
            .attr("class", "enter")
            .attr("r", 5)
            .attr("cx", function(d){return x(d.v0)})
            .attr("cy", function(d){return y(d.v1)})
          // .transition(t)
            .attr("fill","green")

    this.draw = function (newdata){

        var t = d3.transition().duration(750);

        this.svg.selectAll('.xaxis').remove();
        this.svg.selectAll('.yaxis').remove();
        this.svg.selectAll('.line').remove();
        // this.svg.selectAll('circle').remove();

        x.domain(d3.extent(newdata, function(d) {return +d.v0;}));
        y.domain(d3.extent(newdata, function(d) {return +d.v1;}));

        // newdata.forEach(function(d) {
            // d.v0 = +d.v0;
            // d.v1 = +d.v1;
        // })
        // define group and join
        circle = this.svg.selectAll("circle")
                             .data(newdata,function(d){return d.id;});

        // EXIT old elements not present in new data.
        // console.log("3:",circle)
        // circle.exit().text(function(d){d.name;});
        circle.exit().remove();
            
        // circle.exit().remove();

        // console.log(exit);

        // circle.transition(t);
        // console.log(t);
        // UPDATE old elements present in new data.
        // console.log("1:",circle)
        circle.transition(t)
              .attr("class","update")
              .attr("r", 5)
              // .attr("cx",function(d){console.log("scatterplot adding " + d.name);return x(+d.v0)})
              .attr("cx",function(d){return x(+d.v0)})
              .attr("cy",function(d){return y(+d.v1)});     

        // ENTER new elements present in new data.
        // console.log("2:",circle)
        circle.enter().append("circle")
              .attr("class", "enter")
            // .transition(t)
              .attr("r", 5)
              // .attr("cx", function(d){ console.log("scatterplot adding " + d.name); return x(+d.v0)})
              .attr("cx", function(d){return x(+d.v0)})
              .attr("cy", function(d){return y(+d.v1)})

        var x_mean = d3.mean(newdata,function(d){return d.v0});
        var y_mean = d3.mean(newdata,function(d){return d.v1});

        var a0 = 0;
        var a1 = 0;

        var xr = 0;
        var yr = 0;

        for(var i = 0; i < newdata.length; i++){
        	xr = newdata[i].v0 - x_mean;
        	yr = newdata[i].v1 - y_mean;
        	a0 += xr * xr;
        	a1 += yr * yr;
        }

        var b1 = a0 / a1;
        var b0 = y_mean - (b1 * x_mean);

        var reg_points = [];
        for (var i = 0; i < newdata.length; i++) {
            reg_points.push({"x":newdata[i].v0,
            				 "y":b0 + (newdata[i].v0 * b1)});
        }


        var reg_line = d3.line()
        	.x(function(d) {return d.x})
        	.y(function(d) {return d.y});

       	// var reg_line = lineGenerator(reg_points);
    	
    	console.log(reg_points);
    	// console.log(reg_line);

        this.svg.append("path")
        	.datum(reg_points)
            .transition(t)
        	.attr("class","line")
            .attr("d", reg_line);

        this.svg.append('g')
            .attr("class","xaxis")
            .attr('transform', `translate(${0}, ${height+margins.top})`)
            .style('font-style', 'italic')
            .call(xAxis);

        this.svg.append('g')
            .attr("class","yaxis")
            .attr('transform', `translate(${margins.left}, ${0})`)
            .style('font-style', 'italic')
            .call(yAxis);
    }
    // return this;
}
