// this is where your implementation for your flow diagram should go 
function FlowDiagram(svg, data) {
    this.svg = svg;
    
    // grab the bounding box of the container
    var boundingBox = svg.node().getBoundingClientRect();

    //  grab the width and height of our containing SVG
    var svgHeight = boundingBox.height;
    var svgWidth = boundingBox.width;

    // this is where your code should go to generate the flow diagram from the random data
    this.svg.attr("width",svgWidth)
        .attr("height",svgHeight)

    this.svg.append("g")
        .attr("transform","translate(32,"+(svgHeight/2)+")");

    var text = this.svg.selectAll("text")
        .data(data, function(d){return d.id;});

    text.enter().append("text")
            .attr("class","enter")
            .attr("dy",".35em")
            .attr("x",30)
            .style("fill","green")
            .attr("y",function(d,i){return 10+i*13;})
            .style("full-opacity",1)
            .text(function(d){return d.name;});

    var sBand = d3.scaleBand()
                      .domain(['enter','update','exit'])
                      .range([0,svgWidth]);
    console.log(sBand);


    // var t = d3.transition().duration(750);

	this.draw = function (newdata){
        // JOIN new data with old elements
        // this.svg.selectAll('.exit').remove();

        console.log(newdata)

        var text = this.svg.selectAll("text")
            .data(newdata, function(d){return d.name;});

            
        var t = d3.transition().duration(750);

        // EXIT old elements not present in new data
        var i = 0
        text.exit()
          .transition(t)
            .attr("class","exit")
            .attr("x", sBand('exit'))
            .attr("y",function(d){i = i+1; return 10+i*13;})
            .style("fill-opacity", 1)
            .style("fill","red")
            .text(function(d){return d.name;})
            .remove();

        // UPDATE old elements present in new data
        i = 0;
        text.style("fill", "orange")
          .transition(t)
            .attr("x", sBand('update'))
            .attr("y",function(d){i = i+1; return 10+i*13;})
            .style("fill-opacity", 1)
            .text(function(d){return d.name;});

        // ENTER new elements present in new data
        i = 0;
        text.enter().append("text")
          .transition(t)
            .attr("class","enter")
            .attr("dy",".35em")
            .attr("x", sBand('enter'))
            .style("fill","green")
            .attr("y",function(d){i = i+1; return 10+i*13;})
            .style("full-opacity",1)
            .text(function(d){return d.name;});

    }

}
