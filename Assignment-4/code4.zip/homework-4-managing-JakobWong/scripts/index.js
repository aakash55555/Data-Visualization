// This is what you could consider the "central control" file 

// global variables for our visualizations
var flowDiagram = undefined;
var scatterPlot = undefined;
var url = './data/names.csv'

var names=[];

data = d3.csv(url,function(d){ return d;})

console.log("data=",data)

initCharts(data)
tickDataFlow(data)

// only called once, to instantiate your charts
function initCharts(data) {
    // instantiate the flow diagram, and send it the container it should exist in (.flow)
    flowDiagram = new FlowDiagram(d3.select('.flow'), data);
    // console.log(flowDiagram)
    // instantiate the scatter plot, and send it the container it should exist in (.scatter)
    scatterPlot = new ScatterPlot(d3.select('.scatter'), data);
    // console.log(scatterPlot)
}

// called every time the data updates
function tickDataFlow(newData) {
    console.log("Data updated:", newData);
    // you'll probably want to implement these functions and call them :)
    // flowDiagram.draw(newData); 
    scatterPlot.draw(newData);
    flowDiagram.draw(newData); 
    // flowDiagram.draw(newData);
}
